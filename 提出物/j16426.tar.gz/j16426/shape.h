// 16426 福澤大地

#ifndef SHAPE_H
#define SHAPE_H

void drawCircle(double, double, double, int);
void putSprite(GLuint, double, double, double, double, double);

#endif
